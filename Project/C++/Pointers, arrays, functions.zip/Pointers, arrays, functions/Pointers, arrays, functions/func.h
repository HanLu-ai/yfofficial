#pragma once
#include <iostream>
using namespace std;

void bubbleSort(int* arr, int len); // int * arrҲ����дΪint arr[]

void printArray(int arr[], int len);