#include <iostream>
using namespace std;

int main() {
	cout << "��ӭʹ�����繤���ҽ̳�" << endl;
	// ��ֵ�����
	// =
	int a = 10; // ��10��ֵ������a
	a = 100;
	cout << "a=" << a << endl;

	// +=
	a = 10;
	a += 2; // a = a + 2
	cout << "a = " << a << endl;

	// -=
	a = 10;
	a -= 2; // a = a - 2
	cout << "a = " << a << endl;

	// *=
	a = 10;
	a *= 2; // a = a * 2
	cout << "a = " << a << endl;

	// /=
	a = 10;
	a /= 2; // a = a / 2
	cout << "a = " << a << endl;

	// %=
	a = 10;
	a %= 2; // a = a % 2
	cout << "a = " << a << endl;

	system("pause");
	return 0;
}