#pragma once
#include <iostream>
using namespace std;
void swap1(int a, int b);
void swap2(int* p1, int* p2);