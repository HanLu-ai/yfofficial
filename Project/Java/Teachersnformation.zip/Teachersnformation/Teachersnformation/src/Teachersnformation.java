public class Teachersnformation {
    public static void main(String[] args) {
        System.out.println("欢迎使用御风工作室教程");

        // 1.定义字符串类型的变量记录老师的姓名
        String name = "御风工作室寒露1726";
        // 2.定义整数类型的变量记录老师的年龄
        int age = 20;
        // 3.定义整数类型的变量记录老师的性别
        char gender = '男';
        // 4.定义小数类型的变量记录老师的身高
        double height = 182.0;
        // 5.定义布尔类型的变量记录老师的婚姻状况
        boolean flag = true;

        // 输出5个变量的值
        System.out.println(name);
        System.out.println(age);
        System.out.println(gender);
        System.out.println(height);
        System.out.println(flag);
    }
}
