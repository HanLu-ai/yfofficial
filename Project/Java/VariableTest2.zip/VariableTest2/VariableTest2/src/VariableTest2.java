public class VariableTest2 {
    public static void main(String[] args) {
        System.out.println("欢迎使用御风工作室教程");
        // 1.定义字符串变量记录电影的名称
        String movie = "送初恋回家";
        // 2.定义三个变量记录主演的名字
        String name1 = "刘鑫";
        String name2 = "张雨提";
        String name3 = "高媛";
        // 3.定义整数类型的变量记录年龄的年份
        int year = 2020;
        // 4.定义小数类型的变量记录电影的评分
        double score = 9.0;

        // 打印变量的信息
        System.out.println(movie);
        System.out.println(name1);
        System.out.println(name2);
        System.out.println(name3);
        System.out.println(year);
        System.out.println(score);
    }
}
