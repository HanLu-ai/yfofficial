public class ArithmeticOperators {
    public static void main(String[] args) {
        System.out.println("欢迎使用御风工作室教程");
        System.out.println(10 / 3);
        System.out.println(10.0 / 3);
        System.out.println(10 % 2);
        System.out.println(10 % 3);
        System.out.println(15 % 2);
    }
}