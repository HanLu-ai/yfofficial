public class Commonlyuseddatatypes {
    public static void main(String[] args) {

        // 整数：int
        // 小数：(浮点数) double

        // 定义一个证书类型的变量
        // 数据类型 变量名 = 数据值;
        int a = 16;
        System.out.println(a); // 16

        // 定义一个小数类型的变量
        double b = 10.1;
        System.out.println(b); // 10.1
    }
}
