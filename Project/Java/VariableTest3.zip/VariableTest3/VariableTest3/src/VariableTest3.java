public class VariableTest3{
    public static void main(String[] args){


        System.out.println("欢迎使用御风工作室教程");
        //1.定义小数类型的变量记录手机的价格
        double price = 5299.0;

        //2.定义字符串类型的变量记录手机的品牌
        String brand = "华为";

        //输出变量记录的值
        System.out.println(price);
        System.out.println(brand);
    }
}